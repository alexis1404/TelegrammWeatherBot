<?php

namespace App\Http\Controllers;

use Illuminate\Http\JsonResponse;
use App\Services\OpenWeatherMapApiService;
use Illuminate\Http\Request;

class BotController extends Controller
{
    private $map_service;

    public function __construct(OpenWeatherMapApiService $map_service)
    {
        $this->map_service = $map_service;
    }

    public function index()
    {
        echo '<h1>HELLO!</h1>';
    }
}
