<?php

namespace App\Services;

use GuzzleHttp;

class OpenWeatherMapApiService
{
    public function getWeatherFofCity($city_name)
    {
        $weather_content_message = null;

        $url = 'http://api.openweathermap.org/data/2.5/weather?q='
            . $city_name .',ru&appid=668951de2812f4940b081b3f2b084de0&units=metric';

        $client = new GuzzleHttp\Client();

        try {

            $res = $client->request('GET', $url);

        }catch (GuzzleHttp\Exception\ClientException $e){
            $weather_content_message = false;
            return $weather_content_message;
        }

        $weather_content = json_decode($res->getBody()->getContents(), true);

        $weather_content_message = $weather_content['main']['temp'] .
            '  ' . $weather_content['wind']['speed'] .
            'm/s  '  .$weather_content['weather'][0]['description'];

        return $weather_content_message;

    }
}