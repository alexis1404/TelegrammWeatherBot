<?php

namespace App\Services;

use Telegram;
use App\Services\OpenWeatherMapApiService;

class TelegramBotService
{
    private $weather_service;

    public function __construct(OpenWeatherMapApiService $w_service)
    {
        $this->weather_service = $w_service;
    }

    public function botWeatherInSitySpeak()
    {
        $telegram = new Telegram\Bot\Api('572481825:AAFUY64swb3Ffl7E1Y4gd6PTWuYXMMz0wnI');

        $user_full_message_content = $telegram->getWebhookUpdates();

        $text = (string)$user_full_message_content["message"]["text"];
        $chat_id = $user_full_message_content["message"]["chat"]["id"];
//        $keyboard = [["Старт!"]];

        if($text){

            $trim_message = trim($text);

            $weather_result = $this->weather_service->getWeatherFofCity($trim_message);

            if($weather_result){

                $telegram->sendMessage([

                    'chat_id' => $chat_id,
                    'text' => $weather_result
                ]);

            }else{
                $telegram->sendMessage([
                    'chat_id' => $chat_id,
                    'text' => "Хм... Вы ввели что-то не то (а, возможно, я просто не знаю такого города). Повторите, пожалуйста!"
                ]);
            }

        }else{

            $telegram->sendMessage([
                'chat_id' => $chat_id,
                'text' => "Отправьте текстовое сообщение (оно не может быть пустым!)"
            ]);
        }
    }
}